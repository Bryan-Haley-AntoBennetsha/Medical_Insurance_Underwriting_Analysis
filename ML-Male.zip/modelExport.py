
import evalml
import woodwork as ww
import pandas as pd

PATH_TO_TRAIN = "train"
PATH_TO_HOLDOUT = "holdout"
TARGET = "f_6"
column_mapping = "columnMapping.json"

# This is the machine learning pipeline you have exported.
# By running this code you will fit the pipeline on the files provided
# and you can then use this pipeline for prediction and model understanding.
from evalml.pipelines.regression_pipeline import RegressionPipeline
from featuretools import load_features

features = load_features("features.json")
pipeline = RegressionPipeline(
    component_graph={
        "DFS Transformer": ["DFS Transformer", "X", "y"],
        "Numeric Pipeline - Select Columns By Type Transformer": [
            "Select Columns By Type Transformer",
            "DFS Transformer.x",
            "y",
        ],
        "Numeric Pipeline - Imputer": [
            "Imputer",
            "Numeric Pipeline - Select Columns By Type Transformer.x",
            "y",
        ],
        "Numeric Pipeline - Standard Scaler": [
            "Standard Scaler",
            "Numeric Pipeline - Imputer.x",
            "y",
        ],
        "Numeric Pipeline - Select Columns Transformer": [
            "Select Columns Transformer",
            "Numeric Pipeline - Standard Scaler.x",
            "y",
        ],
        "Categorical Pipeline - Select Columns Transformer": [
            "Select Columns Transformer",
            "DFS Transformer.x",
            "y",
        ],
        "Categorical Pipeline - Imputer": [
            "Imputer",
            "Categorical Pipeline - Select Columns Transformer.x",
            "y",
        ],
        "Categorical Pipeline - One Hot Encoder": [
            "One Hot Encoder",
            "Categorical Pipeline - Imputer.x",
            "y",
        ],
        "Categorical Pipeline - Standard Scaler": [
            "Standard Scaler",
            "Categorical Pipeline - One Hot Encoder.x",
            "y",
        ],
        "Elastic Net Regressor": [
            "Elastic Net Regressor",
            "Numeric Pipeline - Select Columns Transformer.x",
            "Categorical Pipeline - Standard Scaler.x",
            "y",
        ],
    },
    parameters={
        "DFS Transformer": {"features": features},
        "Numeric Pipeline - Select Columns By Type Transformer": {
            "column_types": ["category", "EmailAddress", "URL"],
            "exclude": True,
        },
        "Numeric Pipeline - Imputer": {
            "categorical_impute_strategy": "most_frequent",
            "numeric_impute_strategy": "mean",
            "boolean_impute_strategy": "most_frequent",
            "categorical_fill_value": None,
            "numeric_fill_value": None,
            "boolean_fill_value": None,
        },
        "Numeric Pipeline - Select Columns Transformer": {
            "columns": ["f_0", "f_2", "f_3"]
        },
        "Categorical Pipeline - Select Columns Transformer": {"columns": ["f_5"]},
        "Categorical Pipeline - Imputer": {
            "categorical_impute_strategy": "most_frequent",
            "numeric_impute_strategy": "mean",
            "boolean_impute_strategy": "most_frequent",
            "categorical_fill_value": None,
            "numeric_fill_value": None,
            "boolean_fill_value": None,
        },
        "Categorical Pipeline - One Hot Encoder": {
            "top_n": 10,
            "features_to_encode": None,
            "categories": None,
            "drop": "if_binary",
            "handle_unknown": "ignore",
            "handle_missing": "error",
        },
        "Elastic Net Regressor": {"alpha": 0.0001, "l1_ratio": 0.15, "max_iter": 1000},
    },
    random_seed=0,
)


print(pipeline.name)
print(pipeline.parameters)
pipeline.describe()

df = ww.deserialize.from_disk(PATH_TO_TRAIN)
y_train = df.ww[TARGET]
X_train = df.ww.drop(TARGET)
pipeline.fit(X_train, y_train)

# You can now generate predictions as well as run model understanding.
df = ww.deserialize.from_disk(PATH_TO_HOLDOUT)
y_holdout = df.ww[TARGET]
X_holdout = df.ww.drop(TARGET)

pipeline.predict(X_holdout)

# Note: if you have a column mapping, to predict on new data you have on hand
# Map the column names and run prediction
# X_test = X_test.rename(column_mapping, axis=1)
# pipeline.predict(X_test)

# For more info please check out:
# https://evalml.alteryx.com/en/stable/user_guide/automl.html
